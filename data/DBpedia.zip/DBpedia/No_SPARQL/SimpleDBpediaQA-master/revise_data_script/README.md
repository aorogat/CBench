# RevisedDBpediaQA


The script gets the file name as input and produces output.txt as the revised dataset. (Expanding subjects and adding objects)

example: python3 add_redirects_objects.py test.json


Here is the link for the revised datasets:

https://drive.google.com/drive/folders/17ZPAlS3WFE9lyYsJHEMdp924epL7zuLF?usp=sharing
