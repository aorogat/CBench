This directory contains associated files for the paper "TempQuestions: A Benchmark for Temporal Question Answering".

* TempQuestion.json: Questions, gold answers, temporal signals, question types, data sources, and question creation date

* AQQU\_on\_TempQuestions.json: Questions, gold answers, AQQU answers

* QUINT\_on\_TempQuestions.json: Questions, gold answers, QUINT answers 